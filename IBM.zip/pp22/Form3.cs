﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace pp22
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.Columns.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string con = "Data Source=.\\SQLEXPRESS;AttachDbFilename=D:\\APP C#\\pp22\\pp22\\mbi.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";


            SqlConnection conexao = new SqlConnection(con);
            SqlCommand cmd = new SqlCommand("SELECT * From T1", conexao);
            try
            {
                conexao.Open();
                cmd.ExecuteNonQuery();
                SqlDataAdapter da = new SqlDataAdapter();
                DataSet ds = new DataSet();
                da.SelectCommand = cmd;
                da.Fill(ds);
                DataSet
                dataGridView1DataSource = ds;
                dataGridView1.DataMember = ds.Tables[0].TableName;

            }
                catch (Exception ex)
            {

                    MessageBox.Show ("Erro " + ex.Message);
                    
                }
            finally
            {
                conexao.Close();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView1.Columns.Clear();
        }

      
    }
}  
      

    

  


        
    

