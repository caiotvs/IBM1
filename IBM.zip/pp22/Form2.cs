﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace pp22
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string con = "Data Source=.\\SQLEXPRESS;AttachDbFilename=D:\\Nova pasta\\pp22\\pp22\\mbi.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
            SqlConnection conexao = new SqlConnection(con);
            SqlCommand cmd = new SqlCommand("INSERT INTO T1(CONTA)VALUES('" + textBox8.Text + "')", conexao);

        }
        private void button2_Click(object sender, EventArgs e)
        {
            string con = "Data Source=.\\SQLEXPRESS;AttachDbFilename=D:\\Nova pasta\\pp22\\pp22\\mbi.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
            SqlConnection conexao = new SqlConnection(con);
            SqlCommand cmd = new SqlCommand("INSERT INTO T1(CLIENTE)VALUES('" + textBox9.Text + "')", conexao);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string con = "Data Source=.\\SQLEXPRESS;AttachDbFilename=D:\\Nova pasta\\pp22\\pp22\\mbi.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
            SqlConnection conexao = new SqlConnection(con);
            SqlCommand cmd = new SqlCommand("INSERT INTO T1(IDADE)VALUES(" + textBox10.Text + ")", conexao);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string con = "Data Source=.\\SQLEXPRESS;AttachDbFilename=D:\\Nova pasta\\pp22\\pp22\\mbi.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
            SqlConnection conexao = new SqlConnection(con);
            SqlCommand cmd = new SqlCommand("INSERT INTO T1(ENDERECO)VALUES('" + richTextBox2.Text + "')", conexao);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string con = "Data Source=.\\SQLEXPRESS;AttachDbFilename=D:\\Nova pasta\\pp22\\pp22\\mbi.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
            SqlConnection conexao = new SqlConnection(con);
            SqlCommand cmd = new SqlCommand("INSERT INTO T1(SALDO)VALUES(" + textBox12.Text + ")", conexao);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string con = "Data Source=.\\SQLEXPRESS;AttachDbFilename=D:\\Nova pasta\\pp22\\pp22\\mbi.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
            SqlConnection conexao = new SqlConnection(con);
            SqlCommand cmd = new SqlCommand("INSERT INTO T1(EXTRATO)VALUES(" + textBox13.Text + ")", conexao);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string con = "Data Source=.\\SQLEXPRESS;AttachDbFilename=D:\\Nova pasta\\pp22\\pp22\\mbi.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
            SqlConnection conexao = new SqlConnection(con);
            SqlCommand cmd = new SqlCommand("INSERT INTO T1(RELATORIO)VALUES('" + richTextBox1.Text + "')", conexao);


       }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            string con = "Data Source=.\\SQLEXPRESS;AttachDbFilename=D:\\APP C#\\pp22\\pp22\\mbi.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";


            SqlConnection conexao = new SqlConnection(con);
            SqlCommand cmd = new SqlCommand("SELECT * From T1", conexao);
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {
            string con = "Data Source=.\\SQLEXPRESS;AttachDbFilename=D:\\APP C#\\pp22\\pp22\\mbi.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";


            SqlConnection conexao = new SqlConnection(con);
            SqlCommand cmd = new SqlCommand("SELECT * From T1", conexao);
        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {
            string con = "Data Source=.\\SQLEXPRESS;AttachDbFilename=D:\\APP C#\\pp22\\pp22\\mbi.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";


            SqlConnection conexao = new SqlConnection(con);
            SqlCommand cmd = new SqlCommand("SELECT * From T1", conexao);
        }

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {
            string con = "Data Source=.\\SQLEXPRESS;AttachDbFilename=D:\\APP C#\\pp22\\pp22\\mbi.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";


            SqlConnection conexao = new SqlConnection(con);
            SqlCommand cmd = new SqlCommand("SELECT * From T1", conexao);
        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {
            string con = "Data Source=.\\SQLEXPRESS;AttachDbFilename=D:\\APP C#\\pp22\\pp22\\mbi.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";


            SqlConnection conexao = new SqlConnection(con);
            SqlCommand cmd = new SqlCommand("SELECT * From T1", conexao);
        }

        private void textBox13_TextChanged(object sender, EventArgs e)
        {
            string con = "Data Source=.\\SQLEXPRESS;AttachDbFilename=D:\\APP C#\\pp22\\pp22\\mbi.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";


            SqlConnection conexao = new SqlConnection(con);
            SqlCommand cmd = new SqlCommand("SELECT * From T1", conexao);
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            string con = "Data Source=.\\SQLEXPRESS;AttachDbFilename=D:\\APP C#\\pp22\\pp22\\mbi.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";


            SqlConnection conexao = new SqlConnection(con);
            SqlCommand cmd = new SqlCommand("SELECT * From T1", conexao);
        }
    
  
    

    
    }
}

   
